package ru.chikhachev.se;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ChatWindow extends JFrame {
    ChatWindow(){
        setTitle("Chat");
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setBounds(350,200,600,400);

        final JPanel panelForChat = new JPanel();
        JLabel laberForChat = new JLabel("Enter the text");
        final JTextField textForChat = new JTextField(15);
        final JButton buttonForSent = new JButton("Send");

        panelForChat.add(laberForChat);
        panelForChat.add(textForChat);
        panelForChat.add(buttonForSent);

        final JTextArea textForSend = new JTextArea(15,30);

        getContentPane().add(BorderLayout.SOUTH, panelForChat);
        getContentPane().add(BorderLayout.CENTER, new JScrollPane(textForSend));
        setVisible(true);

        buttonForSent.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                textForSend.append(textForChat.getText() + "\n");
                textForChat.setText("");
            }
        });

        textForChat.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                textForSend.append(textForChat.getText() + "\n");
                textForChat.setText("");
            }
        });
    }
}
