package ru.chikhachev.se;

public class App
{
    public static void main( String[] args )
    {
        new ChatWindow();
    }
}
